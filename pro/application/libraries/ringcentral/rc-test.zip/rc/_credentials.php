<?php

return array(
    'username'     => 'hehov@datasoma.com', // your RingCentral account phone number
    'extension'    =>  null, // or number
    'password'     => 'Newpass123',
    'clientId'     => 'B6azN9d2T8Ki8u-9q52U6g',
    'clientSecret' => 'Vm2nDIyGQTWkMIOV80SuEgGoJpUki9QHuXV28whIvAqA',
    'server'       => 'https://platform.devtest.ringcentral.com', // for production - https://platform.ringcentral.com
    'smsNumber'    => '9548669853', // any of SMS-enabled numbers on your RingCentral account
    'mobileNumber' => '4502334176', // your own mobile number to which script will send sms
    'dateFrom'	   => 'yyyy-mm-dd',  // dateFrom
    'dateTo'       => 'yyyy-mm-dd'   // dateTo
);